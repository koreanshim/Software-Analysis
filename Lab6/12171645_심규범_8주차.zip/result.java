package Lab6;
import GenCol.*;

public class result extends entity
{   

	int result;
	
	public result(String name, int _result)
	{  
		super(name);  
		
		result = _result;
	}
	
}
